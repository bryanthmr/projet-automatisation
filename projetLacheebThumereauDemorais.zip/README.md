# projet-automatisation V0 by Eya Lacheeb, Bryan Thumereau and Théo Demorais


Start the project with:
python menu.py
in the shell

AEF.py : file with all functions to manipulate automata
menu.py is for the menu
wordverif.py is a file with a function which is not implemented yet


# Functions complete:
all functions for creation 
all functions for modifications
all functions for deletion

function isDeterministic
function to be deterministic
function mirror
function concatenation
function to generate a regular expression from an automata

# Functions complete with bugs or upgrade needed:
function complementary
function isComplete
function to be complete
function to verify a word
function to print graphically an automata
function product of 2 automata

# Functions not finished yet
function pruned
function equivalent
function minimal